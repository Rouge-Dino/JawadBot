# 🎫 Ticket Bot By BlackKnight683

## ❔ About
This is a simple ticket bot created for a video and as per demand on my [Youtube Channel](https://youtube.com/c/BlackKnight683) :P
It was made in what like 2 days so don't expect some super cool features.....

+ Find a super cool feature ticket bot in my [Discord server](https://discord.gg/S2GGa23)

## 💬 Commands

Command | Description
------------ | -------------
add | Adds a member to a specified ticket.
close | Closes the ticket.
delete | Delete a specified ticket.
help | Shows the help menu.
new | Creates a new ticket.
open | Re-opens a ticket.
ping | Shows the bot's latency.
remove | Removes a member to a specified ticket.
uptime | Grabs the uptime of the bot.

## Startup Command
```js
npm i --production && node index.js
```

## 🙋‍Contributing
If you would like t contribute, please fork this repository and submit a pull request! You can also join the [Discord server](https://discord.gg/S2GGa23) or contact me directly on discord at `•OofyOofOof•#2018`. Anyone is welcome to suggest new features and improve code quality!

## 📄 License
This project is licensed under the Apache License 2.0 - see the [LICENSE](https://github.com/zhon12345/Tavern_Keeper/blob/master/LICENSE) file for details.
